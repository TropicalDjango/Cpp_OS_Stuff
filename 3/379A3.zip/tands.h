#ifndef TANDS_H
#define TANDS_H
#include "tands.cpp"

void Trans(int n);
void Sleep(int n);


#endif
