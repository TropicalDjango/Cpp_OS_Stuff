#ifndef EXTERN_H
#define EXTERN_H

extern Info info;

#endif
