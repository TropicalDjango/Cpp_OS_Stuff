#ifndef PRODUCER_H
#define PRODUCER_H

#include <pthread.h>

void producer(pthread_t *thread_handle);

#endif

