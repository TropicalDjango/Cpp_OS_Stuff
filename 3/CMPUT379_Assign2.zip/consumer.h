#ifndef CONSUMER_H
#define CONSUMER_H

#include <pthread.h>

void *consumer(void *args);

#endif
